var ler = require("./libs/ler.js");


console.log("antes");

console.log("alunos.csv");


console.log("depois");