var express = require("express");
var app = express();


app.get('/', function (req, res) {
    res.send('hello world!');
});

app.get('/turma', function (req, res) {
    res.send('oi turma!');
});

