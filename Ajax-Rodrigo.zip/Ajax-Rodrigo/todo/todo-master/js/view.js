function exibirTarefas() {
    $('#lista-tarefas').empty();
    dados.forEach(function (elem, idx) {
        var checado = (elem.status == 1)? 'checked="checked"' : '';
        var classe = (elem.status == 1)? 'completado' : '';
        
        var tarefa = '<li class="'+ classe +'form-check form-check-inline list-group-item">'
            + '<input type="checkbox" value="'+ idx +'" class="form-check-input chk-status"'+ checado +'/>'
            + elem.titulo
            + '</li>'
        $('#lista-tarefas').append(tarefa);
    });
}