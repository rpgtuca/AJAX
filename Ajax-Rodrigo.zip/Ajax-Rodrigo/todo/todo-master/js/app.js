$(document).ready(function () {

    exibirTarefas();

    $('#novo').keyup(function (ev) {
        if (ev.keyCode == 13) {
            addTarefa($(this).val());
            exibirTarefas();
            $(this).val('');
        };
    });

    $('#lista-tarefas').on('change', '.chk-status', function () {
        alteraStatus($(this).val(), $(this).prop('checked'));

        if ($(this).prop('checked') == true) {
            $(this).parent().addClass('completado');
        }else{
            $(this).parent().removeClass('completado');
        }
    });

});

//console.log(dados);