var dados = iniciaDB();

function iniciaDB() {
    var db = localStorage.getItem('dados');

    if (db == null) {
        return localStorage.setItem('dados', '[]');
    } else {
        return JSON.parse(db);
    }


}

function addTarefa(descricao) {
    if(descricao != ''){
    var novo = {
        titulo: descricao,
        status: 0,
        dataCriacao: new Date()
    };}else{
        // RETORNAR PARA INPUT UM AVISO QUE ESTÁ EM VAZIO.
    }
    dados.push(novo);
    localStorage.setItem('dados', JSON.stringify(dados));
}

function alteraStatus(id, valor) {

    dados[id].status = valor;
    localStorage.setItem('dados', JSON.stringify(dados));
}