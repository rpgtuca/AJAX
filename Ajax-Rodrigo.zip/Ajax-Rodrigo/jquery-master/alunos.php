<?php

$aluno1['nome'] = "Professor pimpão";
$aluno1['data'] = '2010-10-10';
$aluno1['email'] = 'aluno@aluno.com';
$aluno1['codigo'] = 21334;

$aluno2['nome'] = "Aluno pimpão";
$aluno2['data'] = '2010-3-3';
$aluno2['email'] = 'prof@aluno.com';
$aluno2['codigo'] = 32323;

$alunos = array($aluno1, $aluno2);

echo json_encode($alunos);