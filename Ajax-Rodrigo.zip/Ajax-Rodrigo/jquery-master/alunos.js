
$(document).ready(function(){

    //cadastra aluno
    $('#cadastrar').click(function(){

        var pode = true;
        $('input[type=text]').css('border-color', '');
        $('.erro').hide();
        $('.erro').empty();

        $('input[type=text]').each(function(idx, el){
                      
            if($(el).val() === ""){               
                var msg = $(el).attr("erro-msg");

                $('.erro').append(msg + "<br>");

                $(el).css('border-color', 'red');                
                pode = false;                
                $('.erro').show();
            }
        });

        if (pode == true) 
        {

            var codigo = $("input[name=codigo]").val();
            var nome = $("input[name=nome]").val();
            var data = $("input[name=data]").val();
            var email = $("input[name=email]").val();

            $("#listagem tbody").append("<tr>"+
                "<td>"+ codigo +"</td>"+
                "<td>"+ nome +"</td>"+
                "<td>"+ data +"</td>"+
                "<td>"+ email +"</td>"+
                '<td><span class="bt-del">[X]</span></td>'+
                "</tr>"
                );

            
            
            $('input[type=text]').val('');
        }
    }); // Fim do cadastro

    $("input[name=codigo]").keydown(function(ev){
        console.log(ev.keyCode);
        if (ev.keyCode < 48 || ev.keyCode > 57)
        {
            if (ev.keyCode != 8 || ev.keyCode != 46)
            {
                return false;
            }
        }
    });
    
    $("input[name=data]").datepicker({
        dateFormat: "dd/mm/yy"
      });


      $('#carregar').click(function(){
            $.getJSON('alunos.php', function(dados, status){
                dados.forEach(function(item){
                    
                    $("#listagem tbody").append("<tr>"+
                    '<td><input type="checkbox" class="aluno-sel"/></td>'+
                        "<td>"+ item.codigo +"</td>"+
                        "<td>"+ item.nome +"</td>"+
                        "<td>"+ item.data +"</td>"+
                        "<td>"+ item.email +"</td>"+
                        '<td><span class="bt-del">[X]</span></td>'+
                        "</tr>"
                        );

                });
            });
      });
    
      $("#listagem tbody").on('click', '.bt-del',function(){
        $(this).parent().parent().css("background-color", "gold")
            .fadeOut("slow", function(){
                $(this).remove();
            
            }); 
      });

      
    
}); // fim document ready